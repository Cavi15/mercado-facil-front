package com.cavi.mercadofacil;

public class Product {
    public String name;
    public String desc;
    public String price;
    public Product(String name, String desc, String price) {
        this.name = name; this.desc = desc; this.price = price;
    }
}
