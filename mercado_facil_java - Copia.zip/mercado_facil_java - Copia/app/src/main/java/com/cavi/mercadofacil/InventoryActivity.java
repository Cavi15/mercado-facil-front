package com.cavi.mercadofacil;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity implements ProductAdapter.OnItemClickListener {
    RecyclerView recycler;
    ProductAdapter adapter;
    List<Product> products;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        products = new ArrayList<>();
        products.add(new Product("Fone Bluetooth", "Fone sem fio de alta qualidade", "R$ 89,99"));
        products.add(new Product("Teclado Mecânico", "RGB, USB-C", "R$ 129,00"));
        products.add(new Product("Monitor 24\"", "Full HD 75Hz", "R$ 199,99"));
        products.add(new Product("Mouse Gamer", "6 botões programáveis", "R$ 49,90"));
        products.add(new Product("Carregador USB-C", "65W PD", "R$ 29,90"));

        adapter = new ProductAdapter(products, this);
        recycler.setAdapter(adapter);

        ImageButton btnDash = findViewById(R.id.btnDashboard);
        btnDash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(InventoryActivity.this, DashboardActivity.class));
            }
        });
    }

    @Override
    public void onItemClick(int position) {
        Product p = products.get(position);
        Intent it = new Intent(this, ItemDetailActivity.class);
        it.putExtra("name", p.name);
        it.putExtra("desc", p.desc);
        it.putExtra("price", p.price);
        startActivity(it);
    }
}
