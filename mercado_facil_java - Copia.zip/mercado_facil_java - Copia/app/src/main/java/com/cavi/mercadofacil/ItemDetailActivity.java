package com.cavi.mercadofacil;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

public class ItemDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        TextView tvName = findViewById(R.id.tvName);
        TextView tvDesc = findViewById(R.id.tvDesc);
        TextView tvPrice = findViewById(R.id.tvPrice);

        tvName.setText(getIntent().getStringExtra("name"));
        tvDesc.setText(getIntent().getStringExtra("desc"));
        tvPrice.setText(getIntent().getStringExtra("price"));
    }
}
