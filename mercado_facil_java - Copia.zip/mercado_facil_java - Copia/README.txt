Projeto 'Mercado Fácil' (Java). Abra no Android Studio: File > Open > selecione a pasta 'mercado_facil_java'.

Observações:
- Projeto é focado no visual (layouts em XML) e possui Activities: Welcome, Login, Inventory, ItemDetail, Dashboard.
- Use Gradle/Android Studio para sincronizar. MPAndroidChart está incluído como dependência no build.gradle do app.
- Linguagem Java.
